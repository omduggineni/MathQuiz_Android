package com.example.omduggineni.operationsquiz;

import android.content.Context;
import android.graphics.Bitmap;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;

/*
 * Created by Om Duggineni on 1/5/2018.
 */

public class Problem extends Thread{
    Bitmap screenshot;
    double timetaken;
    int rightanswer;
    int answerclicked;
    boolean answasright;
    int probnum;
    String pathname;
    Context context;

    public Problem(int Probnum, Bitmap Screenshot, int Rightanswer, int Answerclicked, Context context1, long timetakenns){
        context = context1;
        probnum = Probnum;
        screenshot = Screenshot;
        rightanswer = Rightanswer;
        answerclicked = Answerclicked;
        answasright = (rightanswer == answerclicked);
        System.out.println("Transcribing bitmap:");
        this.start();
        timetaken = timetakenns/10E9;
    }

    public Problem(String parsethis){
        String[] split = parsethis.split("$$$");
        pathname = split[0];
        rightanswer = Integer.parseInt(split[1]);
        answerclicked = Integer.parseInt(split[2]);
        answasright = (rightanswer == answerclicked);
    }

    @Override
    public String toString(){
        String result = pathname + "$$$" + rightanswer + "$$$" + answerclicked;
        return result;
    }

    public void run(){
        pathname = probnum + ".jpg";
        System.out.println(pathname);
        File filedir = context.getFilesDir();
        File file = new File(filedir, pathname);
        try {
            file.createNewFile();
            OutputStream stream = new FileOutputStream(file, false);
            screenshot.compress(Bitmap.CompressFormat.JPEG, 50, stream);
        }catch(Exception e){
            System.out.println(e.toString());
        }
        screenshot = null;
    }
}
