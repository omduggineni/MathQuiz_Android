package com.example.omduggineni.operationsquiz;
import android.app.Activity;
import android.content.Intent;
import android.view.View;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class ChooseOperation extends AppCompatActivity {

    Button[] buttons = new Button[4];
    int time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



        setContentView(R.layout.activity_choose_operation);

        buttons[0] = findViewById(R.id.button1);
        buttons[1] = findViewById(R.id.button2);
        buttons[2] = findViewById(R.id.button3);
        buttons[3] = findViewById(R.id.button4);

        buttons[0].setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    time = Integer.parseInt(String.valueOf(((TextView) findViewById(R.id.editTime)).getText()));
                }catch(NumberFormatException e){
                    time = 10;
                }
                Intent intent = new Intent(ChooseOperation.this, Addition.class);
                intent.putExtra("Time", "" + time);
                startActivity(intent);
                new Activity().finish();
            }
        });
        buttons[1].setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    time = Integer.parseInt(String.valueOf(((TextView) findViewById(R.id.editTime)).getText()));
                }catch(NumberFormatException e){
                    time = 10;
                }
                Intent intent = new Intent(ChooseOperation.this, Subtraction.class);
                intent.putExtra("Time", "" + time);
                startActivity(intent);
                new Activity().finish();
            }
        });
        buttons[2].setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    time = Integer.parseInt(String.valueOf(((TextView) findViewById(R.id.editTime)).getText()));
                }catch(NumberFormatException e){
                    time = 10;
                }
                Intent intent = new Intent(ChooseOperation.this, Multiplication.class);
                intent.putExtra("Time", "" + time);
                startActivity(intent);
                new Activity().finish();
            }
        });
        buttons[3].setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    time = Integer.parseInt(String.valueOf(((TextView) findViewById(R.id.editTime)).getText()));
                }catch(NumberFormatException e){
                    time = 10;
                }
                Intent intent = new Intent(ChooseOperation.this, SubtractionPositive.class);
                intent.putExtra("Time", "" + time);
                startActivity(intent);
                new Activity().finish();
            }
        });
    }
}
