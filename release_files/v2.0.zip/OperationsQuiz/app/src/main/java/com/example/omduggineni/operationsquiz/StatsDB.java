package com.example.omduggineni.operationsquiz;

import java.io.*;
import java.util.*;

/**
 * Created by Om Duggineni on 1/12/2018.
 */

public class StatsDB {
    /*
    File structure:
    AverageResponseTime

     */

    static File savepath;
    static Problem[] problems = new Problem[0];
    static File save;
    static Scanner savereader;
    static PrintWriter savewriter;
    static String[] lines;
    static boolean recall;
    static double averageResponseTime;
    static int numproblems;
    static int avgscore;
    static int numrounds = 0;

    public StatsDB(File pathname, String operation){
        savepath = pathname;
        save = new File(savepath, "Stats.dat");
    }
    public void add(Problem prob, int score){
        problems = Arrays.copyOf(problems, problems.length+1);
        problems[problems.length - 1] = prob;
        averageResponseTime = (((averageResponseTime*numproblems)+(prob.timetaken/10E9))/(numproblems+1)); //calculate new average
        if(!prob.answasright){
            avgscore = ((avgscore*numrounds)+score)/(numrounds+1);
            numrounds++;
        }
    }
    public void prepareSave(){

    }
    public void save(){

    }
    public void recall(){

    }
}
