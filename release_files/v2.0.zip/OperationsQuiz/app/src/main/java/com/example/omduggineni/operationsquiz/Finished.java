package com.example.omduggineni.operationsquiz;


import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.*;

public class Finished extends AppCompatActivity {
    int score, probnum;
    TextView text;
    Button button;
    String problems;
    String[] problemsarr;
    Button backbutton, forwardbutton;
    Problem[] problemsobj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finished);

        text = (TextView) findViewById(R.id.textView);
        score = Integer.parseInt(getIntent().getStringExtra("Score"));
        text.setText("Your score was: " + score);
        button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent restart = new Intent(Finished.this, ChooseOperation.class);
                startActivity(restart);
                new Activity().finish();
            }
        });
        if (problems != null) {
            problems = getIntent().getStringExtra("Problems");
            System.out.println(problems);
            problems.substring(1, problems.length() - 2);
            System.out.println(problems);
            problemsarr = problems.split(",");
            problemsobj = new Problem[problemsarr.length];
            for (int i = 0; i < problemsarr.length; i++) {
                problemsobj[i] = new Problem(problemsarr[i]);
            }
        }
    }
}
